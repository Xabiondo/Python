edad = int(input("dime tu edad"))

while edad < 19:
    edad = edad + 1 
    print("la edad ahora es " , edad)