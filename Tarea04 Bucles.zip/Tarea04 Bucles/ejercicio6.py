print("secuencia fibonacci")

x = 0 
y = 1 

fibonacciNumbers = []


for i in range (10):
    fibonacciNumbers.append(x)
    x, y = y, x + y

print(fibonacciNumbers)



    

