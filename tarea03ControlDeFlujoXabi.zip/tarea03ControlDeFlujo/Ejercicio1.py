variable = 5 
if variable % 2 == 0:
    print("la variable es par ")
else:
    print("la variable es inpar")

