variable  = 5

if(variable > 0 ):
    print("el número es positivo")
elif(variable < 0):
    print("el número es negativo")
else:
    print("el número es 0")