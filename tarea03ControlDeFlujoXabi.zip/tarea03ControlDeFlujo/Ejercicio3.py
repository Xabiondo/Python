diaSemana = str(input("dime un día de la semana"))

if diaSemana == "lunes":
    print("es lunes, que mal")
elif diaSemana == "viernes":
    print("es viernes, que bien ")
elif diaSemana =="sábado" or diaSemana == "sabado" or diaSemana== "domingo":
    print("ya es finde")
else:
    print("dia del montón")