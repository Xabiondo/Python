numero = int(input("dime un número"))

if(numero < 0 ):
    numero = numero *-1

print("el valor absoluto es " , numero)