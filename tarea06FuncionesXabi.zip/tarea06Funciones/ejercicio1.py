def datosPersonales():
    nombre = str(input("dime tu nombre"))
    edad = int(input("dime tu edad")) 


    print("te llamas " , nombre)
    print("tu edad  " , edad)
    if edad > 17 :
        print("eres mayor de edad")
    else:
        print("eres menor de edad")
datosPersonales()
    

    