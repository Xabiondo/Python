miLista = [ "xabi" , "miguel" ,"daniel"]


def  laFuncion( xab):
    xab.append("hola")

laFuncion(miLista)
print(miLista)

