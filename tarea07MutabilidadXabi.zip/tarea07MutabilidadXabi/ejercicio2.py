suma = 100 
print(suma)

def miFuncion(suma):
    suma += 50
    print(suma)

miFuncion(suma)

print(suma)